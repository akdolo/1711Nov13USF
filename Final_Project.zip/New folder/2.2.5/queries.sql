SELECT quarter, transaction_type, SUM(cdw_sapp_f_credit_card.transaction_value) AS total_transaction

FROM cdw_sapp_d_time 
JOIN cdw_sapp_f_credit_card ON cdw_sapp_d_time.transaction_id=cdw_sapp_f_credit_card.transaction_id

WHERE cdw_sapp_d_time.year='2018'

GROUP BY quarter, transaction_type;


SELECT cdw_sapp_d_branch.branch_zip, sum(cdw_sapp_f_credit_card.transaction_value) AS Total_Transactions

FROM cdw_sapp_f_credit_card 
JOIN cdw_sapp_d_branch ON cdw_sapp_d_branch.branch_code=cdw_sapp_f_credit_card.branch_code

GROUP BY cdw_sapp_d_branch.branch_zip

ORDER BY Total_Transactions
LIMIT 20;